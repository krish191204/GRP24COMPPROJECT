from datetime import datetime, timedelta

# Class representing a book in the library system
class Book:
    def __init__(self, title, author, available_copies):
        self.title = title  # Title of the book
        self.author = author  # Author of the book
        self.available_copies = available_copies  # Number of copies available for borrowing
        self.due_date = None  # Due date for the borrowed book (initially None)
        self.borrower = None  # The current borrower of the book (initially None)

    # String representation of the book object
    def __str__(self):
        # If the book is borrowed, display the due date along with the book details
        status = f" (Due: {self.due_date.strftime('%Y-%m-%d')}" if self.due_date else ""
        return f"{self.title} by {self.author} (Available: {self.available_copies}){status}"

    # Method to borrow the book
    def borrow(self, borrower):
        if self.available_copies > 0:  # Check if copies are available for borrowing
            self.available_copies -= 1  # Reduce the count of available copies
            self.due_date = datetime.now() + timedelta(days=14)  # Set due date for 2 weeks
            self.borrower = borrower  # Record the borrower
            return True  # Indicate successful borrowing
        return False  # Indicate failure (no copies available)

    # Method to return the book
    def return_book(self):
        self.available_copies += 1  # Increase the count of available copies
        self.due_date = None  # Clear the due date
        borrower = self.borrower  # Save the current borrower
        self.borrower = None  # Clear the borrower
        return borrower  # Return the borrower's name for tracking purposes

    # Method to check if the book is overdue
    def is_overdue(self):
        # A book is overdue if its due date exists and the current date is past the due date
        return self.due_date and datetime.now() > self.due_date

    # Static method to display a list of books
    @staticmethod
    def display_books(books):
        # Loop through each book in the list and print its details
        for book in books:
            print(book)