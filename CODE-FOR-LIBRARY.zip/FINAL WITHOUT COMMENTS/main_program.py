from tkinter import Tk, Frame, Button, Label, Listbox, Scrollbar, StringVar, messagebox, simpledialog, OptionMenu
from book_borrowing_system import UserLoginSystem, BorrowBookSystem, User  
from book_collection import Book
from overdue_report import generate_overdue_and_due_date_report
from datetime import datetime, timedelta

class LibraryManagementSystem:
    def __init__(self, master):
        # Initialize the main application window
        self.master = master
        self.master.title("Library Management System")
        self.master.geometry("800x600")

        # Initialize UserLoginSystem for managing user accounts
        self.user_system = UserLoginSystem()

        # Initialize BorrowBookSystem with a reference to UserLoginSystem
        self.book_system = BorrowBookSystem(self.user_system)

        # Load sample data for books and users
        self.initialize_sample_data()

        # Create the GUI widgets
        self.create_widgets()

        # Initialize the chatbot with predefined questions and answers
        self.initialize_chatbot()

        # Display the sample data in the GUI
        self.display_sample_data()

    # Defining a simple chatbot class for handling predefined questions and answers
    class ChatBot:
        def __init__(self):
            # Initialize an empty dictionary to act as the hash table
            self.table = {} 
    
        def put(self, key, value):
            # Add a key-value pair to the hash table
            self.table[key] = value
    
        def get(self, key):
            # Retrieve the value for a given key, or return a default message if the key is not found
            return self.table.get(key, "I don't understand that question.")
    
        def __contains__(self, key):
            # Check if a key exists in the hash table
            return key in self.table

    def initialize_chatbot(self):
        # Initialize the chatbot and add predefined questions and answers
        self.chatbot = self.ChatBot()
        self.chatbot.put("How do I borrow a book?", "Click 'Borrow Book', select a book from the list, and enter your username.")
        self.chatbot.put("What's the loan period?", "Books are loaned for 14 days (2 weeks).")
        self.chatbot.put("How many books can I borrow?", "You can borrow up to 5 books at a time.")
        self.chatbot.put("What if a book is overdue?", "Overdue books incur a fine of $0.50 per day.")
        self.chatbot.put("How do I return a book?", "Click 'Return Book', select the book from the list, and enter your username.")
        self.chatbot.put("Can I renew my books?", "Yes, books can be renewed once for another 14 days.")
        self.chatbot.put("Library opening hours?", "Monday-Friday: 9am-9pm\nSaturday: 10am-6pm\nSunday: 12pm-5pm")

    def initialize_sample_data(self):
        # Initialize sample books
        self.book_system.books = [
            Book("1984", "George Orwell", 3),
            Book("Dune", "Frank Herbert", 2),
            Book("The Hobbit", "J.R.R. Tolkien", 4),
            Book("Fahrenheit 451", "Ray Bradbury", 1),
            Book("Brave New World", "Aldous Huxley", 2)
        ]
        
        # Initialize sample users with borrowing history
        today = datetime.now()
        
        # Create a sample user "Sufi" with borrowed books
        sufi = User("Sufi")
        sufi.full_name = "John Doe"
        sufi.email = "john@example.com"
        sufi.update_borrowing_history("1984", today - timedelta(days=5), today + timedelta(days=9))
        sufi.update_borrowing_history("Dune", today - timedelta(days=3), today + timedelta(days=11))
        self.user_system.users["Sufi"] = sufi

        # Create a sample user "Krish" with borrowed books
        krish = User("Krish")
        krish.full_name = "Jane Smith"
        krish.email = "jane@example.com"
        krish.update_borrowing_history("The Hobbit", today - timedelta(days=7), today + timedelta(days=7))
        self.user_system.users["Krish"] = krish
        
        # Create an admin user
        admin = User("admin")
        admin.full_name = "System Admin"
        admin.email = "admin@library.com"
        self.user_system.users["admin"] = admin
        
        # Update book statuses to match user borrowings
        for book in self.book_system.books:
            if book.title in ["1984", "Dune"]:
                book.borrow("Sufi")
                book.available_copies -= 1
            elif book.title == "The Hobbit":
                book.borrow("Krish")
                book.available_copies -= 1

    def create_widgets(self):
        # Create the main frame for the application
        self.frame = Frame(self.master)
        self.frame.pack(pady=20)
        
        # Add a title label
        self.title_label = Label(self.frame, text="Library Management System", font=("Arial", 16))
        self.title_label.pack(pady=10)

        # Create a frame for the book listbox and scrollbar
        self.list_frame = Frame(self.frame)
        self.list_frame.pack()
        
        # Add a scrollbar for the book listbox
        self.scrollbar = Scrollbar(self.list_frame)
        self.scrollbar.pack(side="right", fill="y")
        
        # Add a listbox to display books
        self.book_listbox = Listbox(
            self.list_frame, 
            width=80, 
            height=15,
            yscrollcommand=self.scrollbar.set
        )
        self.book_listbox.pack(side="left")
        self.scrollbar.config(command=self.book_listbox.yview)

        # Create a frame for the buttons
        self.button_frame = Frame(self.frame)
        self.button_frame.pack(pady=10)
        
        # Add buttons for various actions
        self.borrow_button = Button(self.button_frame, text="Borrow Book", command=self.borrow_book, width=15)
        self.borrow_button.grid(row=0, column=0, padx=5)
        
        self.return_button = Button(self.button_frame, text="Return Book", command=self.return_book, width=15)
        self.return_button.grid(row=0, column=1, padx=5)
        
        self.login_button = Button(self.button_frame, text="User Login", command=self.user_login, width=15)
        self.login_button.grid(row=0, column=2, padx=5)
        
        self.report_button = Button(self.button_frame, text="Generate Report", command=self.generate_report, width=15)
        self.report_button.grid(row=1, column=0, pady=5)
        
        self.chatbot_button = Button(self.button_frame, text="Library Chatbot", command=self.open_chatbot, width=15)
        self.chatbot_button.grid(row=1, column=1, pady=5)
        
        self.exit_button = Button(self.button_frame, text="Exit", command=self.master.quit, width=15)
        self.exit_button.grid(row=1, column=2, pady=5)

    def display_sample_data(self):
        # Display the sample books in the listbox
        self.display_books()
        # Print sample user information to the console
        print("\nSample Users Available:")
        print("1. Sufi - Borrowed: 1984, Dune")
        print("2. Krish - Borrowed: The Hobbit")
        print("3. admin - No books borrowed")

    def borrow_book(self):
        # Handle the borrowing of a book
        try:
            # Get the selected book from the listbox
            selected_index = self.book_listbox.curselection()[0]
            selected_book = self.book_system.books[selected_index]
            
            if selected_book.available_copies > 0:
                # Prompt the user for their username
                username = simpledialog.askstring("Borrow Book", "Enter your username:")
                if username:
                    try:
                        # Attempt to log in the user
                        user = self.user_system.login(username)
                        if selected_book.borrow(username):
                            # Update the user's borrowing history
                            self.user_system.users[username].update_borrowing_history(
                                selected_book.title, datetime.now(), selected_book.due_date)
                            messagebox.showinfo("Success", f"You've borrowed '{selected_book.title}'\nDue date: {selected_book.due_date.strftime('%Y-%m-%d')}")
                            self.display_books()
                    except ValueError as e:
                        messagebox.showerror("Login Failed", str(e))
                else:
                    messagebox.showerror("Error", "Username cannot be empty")
            else:
                messagebox.showerror("Error", "No copies available for borrowing")
        except IndexError:
            messagebox.showerror("Error", "Please select a book first")

    def return_book(self):
        # Handle the returning of a book
        try:
            # Get the selected book from the listbox
            selected_index = self.book_listbox.curselection()[0]
            selected_book = self.book_system.books[selected_index]
            
            # Prompt the user for their username
            username = simpledialog.askstring("Return Book", "Enter your username:")
            if username:
                try:
                    # Attempt to log in the user
                    user = self.user_system.login(username)
                    if selected_book.title in user['borrowed_books']:
                        # Return the book and update the user's borrowing history
                        returned_borrower = selected_book.return_book()
                        if returned_borrower:
                            self.user_system.users[username].update_borrowing_history(
                                selected_book.title, None, None, is_returned=True)
                            messagebox.showinfo("Success", f"You've returned '{selected_book.title}'")
                            self.display_books()
                    else:
                        messagebox.showerror("Error", "You didn't borrow this book")
                except ValueError as e:
                    messagebox.showerror("Login Failed", str(e))
            else:
                messagebox.showerror("Error", "Username cannot be empty")
        except IndexError:
            messagebox.showerror("Error", "Please select a book first")

    def display_books(self):
        # Display the list of books in the listbox
        self.book_listbox.delete(0, 'end')
        for book in self.book_system.books:
            status = "Available" if book.available_copies > 0 else "Checked Out"
            due_info = f" (Due: {book.due_date.strftime('%Y-%m-%d')})" if book.due_date else ""
            self.book_listbox.insert('end', 
                f"{book.title.ljust(30)} by {book.author.ljust(20)} | Copies: {book.available_copies} | Status: {status}{due_info}")

    def user_login(self):
        # Handle user login
        username = simpledialog.askstring("Login", "Enter username:")
        if username:
            try:
                # Attempt to log in the user
                user = self.user_system.login(username)
                if user:
                    messagebox.showinfo("Login Successful", f"Welcome {user['full_name']}!\nBorrowed Books: {', '.join(user['borrowed_books']) or 'None'}")
            except ValueError as e:
                messagebox.showerror("Login Failed", str(e))

    def generate_report(self):
        # Generate and display a library report
        report = generate_overdue_and_due_date_report(self.book_system)
        messagebox.showinfo("Library Report", report)

    def open_chatbot(self):
        # Open the chatbot window
        chatbot_window = Tk()
        chatbot_window.title("Library Chatbot")
        chatbot_window.geometry("500x300")
        
        # Add a title label for the chatbot
        Label(chatbot_window, text="Library Help Chatbot", font=("Arial", 14)).pack(pady=10)
        
        # Add a dropdown menu for selecting a question
        Label(chatbot_window, text="Select your question:").pack()
        
        selected_question = StringVar(chatbot_window)
        selected_question.set(list(self.chatbot.table.keys())[0])  # default value
        
        question_menu = OptionMenu(chatbot_window, selected_question, *self.chatbot.table.keys())
        question_menu.pack(pady=5)
        
        # Add a label to display the chatbot's answer
        answer_label = Label(chatbot_window, text="", wraplength=400, justify="left")
        answer_label.pack(pady=20)
        
        # Define a function to display the answer for the selected question
        def show_answer():
            answer = self.chatbot.get(selected_question.get())
            answer_label.config(text=answer)

        # Add a button to get the answer
        Button(chatbot_window, text="Get Answer", command=show_answer).pack(pady=10)
        
        chatbot_window.mainloop()

if __name__ == "__main__":
    # Run the application
    root = Tk()
    app = LibraryManagementSystem(root)
    root.mainloop()