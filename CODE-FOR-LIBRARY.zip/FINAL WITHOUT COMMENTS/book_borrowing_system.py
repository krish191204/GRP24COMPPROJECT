from book_collection import Book
from datetime import datetime, timedelta

# Class representing a library user
class User:
    def __init__(self, name):
        self.name = name  # Store user's name
        self.borrowing_history = []  # List to track borrowed books and dates
        self.overdue_books = []  # List to track overdue books
        self.full_name = name  # Compatibility with existing code for full name
        self.email = f"{name.lower()}@example.com"  # Default email format for user

    # Method to update borrowing history for a user
    def update_borrowing_history(self, book_title, borrow_date, due_date, is_returned=False):
        if is_returned:
            # Remove book from borrowing history and overdue list if returned
            self.borrowing_history = [entry for entry in self.borrowing_history if entry[0] != book_title]
            self.overdue_books = [entry for entry in self.overdue_books if entry[0] != book_title]
        else:
            # Add book to borrowing history
            self.borrowing_history.append((book_title, borrow_date, due_date))
            # Add to overdue list if the due date has passed
            if due_date < datetime.now():
                self.overdue_books.append((book_title, due_date))

    # Method to retrieve user's details, borrowing history, and overdue books
    def get_user_info(self):
        return {
            "name": self.name,
            "full_name": self.full_name,
            "email": self.email,
            "borrowed_books": [entry[0] for entry in self.borrowing_history],  # List of currently borrowed books
            "borrowing_history": self.borrowing_history,  # Full borrowing history
            "overdue_books": self.overdue_books  # Overdue books
        }

# Class representing the login system for users
class UserLoginSystem:
    def __init__(self):
        self.users = {}  # Dictionary to store user details
        self.initialize_sample_data()  # Initialize sample user data

    # Method to create sample user data
    def initialize_sample_data(self):
        today = datetime.now()
        
        # Create sample users and update their borrowing history
        james = User("James")
        james.update_borrowing_history("1984", today - timedelta(days=15), today - timedelta(days=1))  # Overdue book
        james.update_borrowing_history("Dune", today - timedelta(days=5), today + timedelta(days=9))  # Current book
        self.users["James"] = james

        mary = User("Mary")
        mary.update_borrowing_history("The Hobbit", today - timedelta(days=10), today - timedelta(days=3))  # Overdue book
        mary.update_borrowing_history("Fahrenheit 451", today - timedelta(days=2), today + timedelta(days=12))  # Current book
        self.users["Mary"] = mary

        john = User("John")
        john.update_borrowing_history("Brave New World", today - timedelta(days=7), today + timedelta(days=7))  # Current book
        self.users["John"] = john

    # Method for user login and retrieving their details
    def login(self, name):
        if name not in self.users:
            raise ValueError(f"User '{name}' not found. Please register first.")
        return self.users[name].get_user_info()

    # Method to register a new user
    def register_user(self, name):
        if name in self.users:
            raise ValueError(f"User '{name}' already exists.")
        self.users[name] = User(name)  # Create new user and add to system
        print(f"User '{name}' registered successfully.")
        return True
    
    # Method to display a user's borrowing information
    def display_user_info(self, name):
        user = self.users.get(name)
        if user:
            info = user.get_user_info()
            print(f"\nUser: {info['name']}")
            print("Borrowing History:")
            # Display borrowing history
            for book, borrow_date, due_date in info['borrowing_history']:
                print(f" - {book} (Borrowed: {borrow_date.strftime('%Y-%m-%d')}, Due: {due_date.strftime('%Y-%m-%d')})")
            print("Currently Borrowed Books:", info['borrowed_books'])
            print("Overdue Books:")
            # Display overdue books
            for book, due_date in info['overdue_books']:
                print(f" - {book} (Due: {due_date.strftime('%Y-%m-%d')})")
        else:
            print(f"User {name} not found.")

# Class representing the system for borrowing and returning books
class BorrowBookSystem:
    def __init__(self, user_system):
        self.books = []  # List to store books available for borrowing
        self.user_system = user_system  # Reference to user login system

    # Method to borrow a book
    def borrow_book(self, title):
        username = input("Enter your username: ")
        try:
            user = self.user_system.login(username)  # Authenticate user
            for book in self.books:
                if book.title.lower() == title.lower() and book.available_copies > 0:
                    # Borrow the book if it's available
                    if book.borrow(username):
                        self.user_system.users[username].update_borrowing_history(
                            book.title, datetime.now(), book.due_date)  # Update user's borrowing history
                        print(f"'{book.title}' has been borrowed by {username}.")
                        return
            print("Book not available or does not exist.")
        except ValueError as e:
            print(str(e))  # Handle login or book issues

    # Method to return a book
    def return_book(self, title):
        username = input("Enter your username: ")
        try:
            user = self.user_system.login(username)  # Authenticate user
            for book in self.books:
                if book.title.lower() == title.lower():
                    # Return the book if the user has borrowed it
                    if book.title in user['borrowed_books']:
                        returned_borrower = book.return_book()
                        if returned_borrower:
                            self.user_system.users[username].update_borrowing_history(
                                book.title, None, None, is_returned=True)  # Update user's borrowing history
                            print(f"'{book.title}' has been returned by {username}.")
                            return
                    else:
                        print(f"{username} did not borrow this book.")
                        return
            print("This book does not belong to our collection.")
        except ValueError as e:
            print(str(e))  # Handle login or book issues