from tkinter import *
from tkinter import messagebox, simpledialog
from book_borrowing_system import UserLoginSystem, BorrowBookSystem
from book_collection import Book
from overdue_report import generate_overdue_and_due_date_report

# Class to create the Graphical User Interface (GUI) for the Library Management System
class LibraryManagementSystemGUI:
    def __init__(self, master):
        self.master = master
        master.title("Library Management System")  # Set the title of the main application window

        # Initialize the user login system for managing user authentication
        self.user_system = UserLoginSystem()
        
        # Initialize the book borrowing system for managing borrowing and returning books
        self.book_system = BorrowBookSystem()

        # Create and arrange all the GUI components for the application
        self.create_widgets()

    # Method to create and set up all widgets (buttons, labels, etc.) for the application
    def create_widgets(self):
        # Title label for the application
        self.title_label = Label(self.master, text="Library Management System", font=("Helvetica", 16))
        self.title_label.pack(pady=10)  # Add some vertical padding for aesthetics

        # Button to display available books
        self.display_books_button = Button(self.master, text="Display Available Books", command=self.display_books)
        self.display_books_button.pack(pady=5)

        # Button to borrow a book
        self.borrow_book_button = Button(self.master, text="Borrow a Book", command=self.borrow_book)
        self.borrow_book_button.pack(pady=5)

        # Button to return a book
        self.return_book_button = Button(self.master, text="Return a Book", command=self.return_book)
        self.return_book_button.pack(pady=5)

        # Button for user login functionality
        self.user_login_button = Button(self.master, text="User Login", command=self.user_login)
        self.user_login_button.pack(pady=5)

        # Button to generate overdue and due date reports
        self.generate_report_button = Button(self.master, text="Generate Overdue and Due Date Report", command=self.generate_report)
        self.generate_report_button.pack(pady=5)

        # Button to exit the application
        self.exit_button = Button(self.master, text="Exit", command=self.master.quit)
        self.exit_button.pack(pady=5)

    # Method to display the list of available books in the system
    def display_books(self):
        books = self.book_system.books  # Retrieve the list of books from the book system
        # Format the list of books to display with title, author, and available copies
        book_list = "\n".join([f"{book.title} by {book.author} - {book.available_copies} copies available" for book in books])
        # Show the list in a messagebox; if no books are available, display a default message
        messagebox.showinfo("Available Books", book_list if book_list else "No books available.")

    # Method to borrow a book
    def borrow_book(self):
        # Prompt the user to enter the title of the book to borrow
        title = simpledialog.askstring("Borrow a Book", "Enter the title of the book you want to borrow:")
        if title:
            result = self.book_system.borrow_book(title)  # Attempt to borrow the book
            messagebox.showinfo("Borrow Book", result)  # Display the result (success or failure)

    # Method to return a book
    def return_book(self):
        # Prompt the user to enter the title of the book to return
        title = simpledialog.askstring("Return a Book", "Enter the title of the book you want to return:")
        if title:
            result = self.book_system.return_book(title)  # Attempt to return the book
            messagebox.showinfo("Return Book", result)  # Display the result (success or failure)

    # Method to handle user login functionality
    def user_login(self):
        # Prompt the user to enter their name for login
        name = simpledialog.askstring("User Login", "Enter your name to log in:")
        if name:
            user = self.user_system.login(name)  # Authenticate the user
            if user:
                messagebox.showinfo("User Login", f"Welcome, {name}!")  # Display a welcome message
                self.user_system.display_user_info(name)  # Display user details and borrowing history
            else:
                messagebox.showerror("User Login", "Login failed. Please try again.")  # Display error for failed login

    # Method to generate and display a report of overdue and due soon books
    def generate_report(self):
        report = generate_overdue_and_due_date_report()  # Generate the report
        messagebox.showinfo("Overdue and Due Date Report", report)  # Display the report in a messagebox

# Main entry point to launch the application
if __name__ == "__main__":
    root = Tk()  # Create the main application window
    app = LibraryManagementSystemGUI(root)  # Initialize the GUI application
    root.mainloop()  # Start the GUI event loop