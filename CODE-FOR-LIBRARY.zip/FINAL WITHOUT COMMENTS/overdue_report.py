from datetime import datetime, timedelta

# Function to generate a report of overdue books and books due soon
def generate_overdue_and_due_date_report(book_system):
    overdue_books = []  # List to store books that are overdue
    due_soon_books = []  # List to store books that are due soon
    
    # Define the time period for "due soon" (e.g., within 2 days)
    due_soon_threshold = timedelta(days=2)
    
    # Iterate through all books in the book system
    for book in book_system.books:
        # Check if the book has a due date and is borrowed
        if hasattr(book, 'due_date') and book.due_date:
            if book.is_overdue():  # Check if the book is overdue
                overdue_books.append(book)  # Add to the list of overdue books
            # Check if the book is due within the threshold but not yet overdue
            elif datetime.now() + due_soon_threshold >= book.due_date and not book.is_overdue():
                due_soon_books.append(book)  # Add to the list of books due soon
    
    # Build the report string
    report = "=== Library Book Status Report ===\n"
    report += "Generated on: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n\n"
    
    # Add details about overdue books to the report
    report += "=== Overdue Books ===\n"
    if overdue_books:
        for book in overdue_books:
            days_overdue = (datetime.now() - book.due_date).days  # Calculate days overdue
            report += ("• {} by {}\n".format(book.title, book.author) +  # Book title and author
                      "  - Due Date: {}\n".format(book.due_date.strftime("%Y-%m-%d")) +  # Due date
                      "  - Days Overdue: {}\n".format(days_overdue) +  # Number of overdue days
                      "  - Fine: ${:.2f}\n\n".format(days_overdue * 0.50))  # Calculate fine ($0.50 per day)
    else:
        report += "No overdue books found.\n\n"
    
    # Add details about books due soon to the report
    report += "=== Books Due Soon ===\n"
    if due_soon_books:
        for book in due_soon_books:
            days_remaining = (book.due_date - datetime.now()).days  # Calculate days remaining until due
            report += ("• {} by {}\n".format(book.title, book.author) +  # Book title and author
                      "  - Due Date: {}\n".format(book.due_date.strftime("%Y-%m-%d")) +  # Due date
                      "  - Days Remaining: {}\n\n".format(days_remaining))  # Number of days remaining
    else:
        report += "No books due soon.\n"
    
    # Add closing statement to the report
    report += "=== End of Report ==="
    
    return report  # Return the generated report string